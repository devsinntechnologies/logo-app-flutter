// ignore_for_file: unnecessary_null_comparison


import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:logo_app_flutter/components/logoBottomNavbarItems/shape_selector_widget.dart';
import 'package:logo_app_flutter/provider/selected_color_provider.dart';
import 'package:provider/provider.dart';

import '../models/logo_state_data.dart';
import 'editable_element_wrapper.dart';
import 'grid_painter.dart';

class LogoCanvas extends StatefulWidget {
  final GlobalKey canvasKey;
  final String selectedShapeName;
  final LogoStateData logoState;
  final String svgLogo;
  final String companyName;
  final String sloganName;
  final bool showGrid;
  final bool isEditingMode;
  final int? selectedElementId;
  final int? highlightedHorizontalGridLineIndex;
  final int? highlightedVerticalGridLineIndex;
  final bool isLayersRibbonExtended;
  final bool isCheckerboardActive;
  final bool isCheckerboardVisible;
  final double checkerboardOpacity;
  final List<int> elementOrder;
  final Set<int> lockedElements;

  final VoidCallback onToggleGrid;
  final VoidCallback onToggleLayersRibbon;
  final ElementTapCallback onElementTap;
  final ElementPanStartCallback onElementPanStart;
  final ElementPanUpdateCallback onElementPanUpdate;
  final ElementPanEndCallback onElementPanEnd;
  final ElementActionCallback onElementDelete;
  final ElementActionCallback onElementSplit;
  final ElementActionCallback onElementRotateTap;
  final ElementPanStartCallback onElementRotatePanStart;
  final ElementDragUpdateCallback onElementRotatePanUpdate;
  final ElementPanEndCallback onElementRotatePanEnd;
  final ElementActionCallback onElementResizeTap;
  final ElementPanStartCallback onElementResizePanStart;
  final ElementDragUpdateCallback onElementResizePanUpdate;
  final ElementPanEndCallback onElementResizePanEnd;

  const LogoCanvas({
    Key? key,
    required this.canvasKey,
    required this.selectedShapeName,
    required this.logoState,
    required this.svgLogo,
    required this.companyName,
    required this.sloganName,
    required this.showGrid,
    required this.isEditingMode,
    required this.selectedElementId,
    this.highlightedHorizontalGridLineIndex,
    this.highlightedVerticalGridLineIndex,
    required this.isLayersRibbonExtended,
    required this.isCheckerboardActive,
    required this.isCheckerboardVisible,
    required this.checkerboardOpacity,
    this.elementOrder = const [],
    this.lockedElements = const {},
    required this.onToggleGrid,
    required this.onToggleLayersRibbon,
    required this.onElementTap,
    required this.onElementPanStart,
    required this.onElementPanUpdate,
    required this.onElementPanEnd,
    required this.onElementDelete,
    required this.onElementSplit,
    required this.onElementRotateTap,
    required this.onElementRotatePanStart,
    required this.onElementRotatePanUpdate,
    required this.onElementRotatePanEnd,
    required this.onElementResizeTap,
    required this.onElementResizePanStart,
    required this.onElementResizePanUpdate,
    required this.onElementResizePanEnd,
  }) : super(key: key);

  @override
  State<LogoCanvas> createState() => _LogoCanvasState();
}

class _LogoCanvasState extends State<LogoCanvas> {
  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<SelectedColorProvider>(context);
    final gradient = provider.selectedGradient;
    final providers = Provider.of<SelectedColorProvider>(context);
    final bgImage = providers.backgroundImage;

    final shapeColor =
        Provider.of<SelectedColorProvider>(context).selectedColor;
    return LayoutBuilder(
      builder: (context, constraints) {
        final Size canvasSize = constraints.biggest;
        return Stack(
          key: widget.canvasKey,
          children: [
            if (widget.showGrid)
              CustomPaint(
                painter: GridPainter(
                  gridColor: Colors.black,
                  highlightedHorizontalLine:
                      widget.highlightedHorizontalGridLineIndex,
                  highlightedVerticalLine:
                      widget.highlightedVerticalGridLineIndex,
                ),
                size: Size.infinite,
              ),

            if (widget.isCheckerboardVisible)
              Opacity(
                opacity: 0.1,
                child: Image.asset(
                  'assets/icons/checkerboard.png',
                  width: double.infinity,
                  height: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),

            if (widget.isCheckerboardVisible &&
                widget.selectedShapeName == "Rounded Rect")
              Opacity(
                opacity: 1 * widget.checkerboardOpacity,
                child: Center(
                  child: CustomPaint(
                    size: const Size(280, 100),
                    painter: SquarePainter(shapeColor, gradient, bgImage),
                  ),
                ),
              ),

            if (widget.isCheckerboardVisible &&
                widget.selectedShapeName == "Diamond")
              Opacity(
                opacity: 1 * widget.checkerboardOpacity,
                child: CustomPaint(
                  size: const Size(double.infinity, double.infinity),
                  painter: DiamondPainter(shapeColor, gradient, bgImage),
                ),
              ),

            if (widget.isCheckerboardVisible &&
                widget.selectedShapeName == "Triangle")
              Opacity(
                opacity: 1 * widget.checkerboardOpacity,
                child: CustomPaint(
                  size: const Size(double.infinity, double.infinity),
                  painter: TrianglePainter(shapeColor, gradient, bgImage),
                ),
              ),
            if (widget.isCheckerboardVisible &&
                widget.selectedShapeName == "Pentagon")
              Opacity(
                opacity: 1 * widget.checkerboardOpacity,
                child: CustomPaint(
                  size: const Size(double.infinity, double.infinity),
                  painter: PentagonPainter(shapeColor, gradient, bgImage),
                ),
              ),
            if (widget.isCheckerboardVisible &&
                widget.selectedShapeName == "Hexagon")
              Opacity(
                opacity: 1 * widget.checkerboardOpacity,
                child: CustomPaint(
                  size: const Size(double.infinity, double.infinity),
                  painter: HexagonPainter(shapeColor, gradient, bgImage),
                ),
              ),
            if (widget.isCheckerboardVisible &&
                widget.selectedShapeName == "Star")
              Opacity(
                opacity: 1 * widget.checkerboardOpacity,
                child: CustomPaint(
                  size: const Size(double.infinity, double.infinity),
                  painter: StarPainter(shapeColor, gradient, bgImage),
                ),
              ),
            if (widget.isCheckerboardVisible &&
                widget.selectedShapeName == "Arrow")
              Opacity(
                opacity: 1 * widget.checkerboardOpacity,
                child: CustomPaint(
                  size: const Size(double.infinity, double.infinity),
                  painter: ArrowPainter(shapeColor, gradient, bgImage),
                ),
              ),
            if (widget.isCheckerboardVisible &&
                widget.selectedShapeName == "Heart")
              Opacity(
                opacity: widget.checkerboardOpacity,
                child: CustomPaint(
                  size: const Size(200, 200),

                  painter: HeartPainter(shapeColor, gradient, bgImage),
                ),
              ),

            if (widget.isCheckerboardVisible &&
                widget.selectedShapeName == "Square")
              Opacity(
                opacity: 1 * widget.checkerboardOpacity,
                child: CustomPaint(
                  size: const Size(double.infinity, double.infinity),
                  painter: SquarePainter(shapeColor, gradient, bgImage),
                ),
              ),

            ...widget.elementOrder
                .map((id) => _buildElementById(id, canvasSize))
                .whereType<Widget>(),
          ],
        );
      },
    );
  }

  Widget? _buildElementById(int id, Size canvasSize) {
    Widget wrap(
      Widget child, {
      required Offset position,
      required double rotation,
    }) {
      return _buildEditableWrapper(
        id: id,
        position: position,
        rotation: rotation,
        isLocked: widget.lockedElements.contains(id),
        child: child,
        canvasSize: canvasSize,
      );
    }

    if (id >= 100) {
      final index = id - 100;
      if (index < widget.logoState.customTexts.length) {
        final customText = widget.logoState.customTexts[index];
        return wrap(
          Text(
            customText.text,
            style: TextStyle(
              fontSize: customText.size,
              color: Colors.black,
              fontWeight: FontWeight.w500,
            ),
          ),
          position: customText.position,
          rotation: customText.rotation,
        );
      }
      return null;
    }

    switch (id) {
      case 0:
        return widget.logoState.isLogoVisible
            ? wrap(
              SvgPicture.string(
                widget.svgLogo,
                height: widget.logoState.logoSize,
                width: widget.logoState.logoSize,
              ),
              position: widget.logoState.logoPosition,
              rotation: widget.logoState.logoRotation,
            )
            : null;
      case 1:
        return widget.logoState.isCompanyNameVisible &&
                widget.logoState.companyName != null
            ? wrap(
              Text(
                widget.logoState.companyName!,
                style: TextStyle(
                  fontSize: widget.logoState.companyNameSize,
                  fontWeight: FontWeight.bold,
                ),
              ),
              position: widget.logoState.companyNamePosition,
              rotation: widget.logoState.companyNameRotation,
            )
            : null;
      case 2:
        return widget.logoState.isSloganVisible &&
                widget.logoState.sloganName != null
            ? wrap(
              Text(
                widget.logoState.sloganName!,
                style: TextStyle(
                  fontSize: widget.logoState.sloganSize,
                  fontStyle: FontStyle.italic,
                ),
              ),
              position: widget.logoState.sloganPosition,
              rotation: widget.logoState.sloganRotation,
            )
            : null;
      case 3:
        return widget.logoState.isLogo2Visible
            ? wrap(
              SvgPicture.string(
                widget.svgLogo,
                height: widget.logoState.logo2Size ?? 100,
                width: widget.logoState.logo2Size ?? 100,
              ),
              position: widget.logoState.logo2Position ?? Offset.zero,
              rotation: widget.logoState.logo2Rotation ?? 0,
            )
            : null;
      case 4:
        return widget.logoState.isCompanyName2Visible &&
                widget.logoState.companyName != null
            ? wrap(
              Text(
                widget.logoState.companyName!,
                style: TextStyle(
                  fontSize: widget.logoState.companyName2Size ?? 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              position: widget.logoState.companyName2Position ?? Offset.zero,
              rotation: widget.logoState.companyName2Rotation ?? 0,
            )
            : null;
      case 5:
        return widget.logoState.isSlogan2Visible &&
                widget.logoState.sloganName != null
            ? wrap(
              Text(
                widget.logoState.sloganName!,
                style: TextStyle(
                  fontSize: widget.logoState.slogan2Size ?? 18,
                  fontStyle: FontStyle.italic,
                ),
              ),
              position: widget.logoState.slogan2Position ?? Offset.zero,
              rotation: widget.logoState.slogan2Rotation ?? 0,
            )
            : null;
      default:
        return null;
    }
  }

  Widget _buildEditableWrapper({
    required int id,
    required Offset position,
    required double rotation,
    required Widget child,
    required Size canvasSize,
    required bool isLocked,
  }) {
    return EditableElementWrapper(
      id: id,
      position: position,
      rotation: rotation,
      isSelected: widget.selectedElementId == id,
      isEditingMode: widget.isEditingMode,
      isLocked: isLocked,
      canvasSize: canvasSize,
      onTap: widget.onElementTap,
      onPanStart: widget.onElementPanStart,
      onPanUpdate: widget.onElementPanUpdate,
      onPanEnd: widget.onElementPanEnd,
      onDelete: widget.onElementDelete,
      onSplit: widget.onElementSplit,
      onRotateTap: widget.onElementRotateTap,
      onRotatePanStart: widget.onElementRotatePanStart,
      onRotatePanUpdate: widget.onElementRotatePanUpdate,
      onRotatePanEnd: widget.onElementRotatePanEnd,
      onResizeTap: widget.onElementResizeTap,
      onResizePanStart: widget.onElementResizePanStart,
      onResizePanUpdate: widget.onElementResizePanUpdate,
      onResizePanEnd: widget.onElementResizePanEnd,
      child: child,
    );
  }
}
