

import 'dart:math';
import 'package:flutter/material.dart';
import 'corner_action_icon.dart';


typedef ElementTapCallback = void Function(int id);
typedef ElementPanUpdateCallback = void Function(int id, Offset delta);
typedef ElementPanStartCallback = void Function(int id, DragStartDetails details);
typedef ElementPanEndCallback = void Function(int id);
typedef ElementActionCallback = void Function(int id);
typedef ElementDragUpdateCallback = void Function(int id, DragUpdateDetails details);

class EditableElementWrapper extends StatelessWidget {
  final int id;
  final Offset position;
  final double rotation;
  final Widget child;
  final Size canvasSize;
  final bool isSelected;
  final bool isEditingMode;
  final bool isLocked; 

  
  final ElementTapCallback onTap;
  final ElementPanStartCallback onPanStart;
  final ElementPanUpdateCallback onPanUpdate;
  final ElementPanEndCallback onPanEnd;
  final ElementActionCallback onDelete;
  final ElementActionCallback onSplit;
  final ElementActionCallback onRotateTap;
  final ElementPanStartCallback onRotatePanStart;
  final ElementDragUpdateCallback onRotatePanUpdate;
  final ElementPanEndCallback onRotatePanEnd;
  final ElementActionCallback onResizeTap;
  final ElementPanStartCallback onResizePanStart;
  final ElementDragUpdateCallback onResizePanUpdate;
  final ElementPanEndCallback onResizePanEnd;

  const EditableElementWrapper({
    super.key,
    required this.id,
    required this.position,
    required this.rotation,
    required this.child,
    required this.canvasSize,
    required this.isSelected,
    required this.isEditingMode,
    required this.isLocked, 
    required this.onTap,
    required this.onPanStart,
    required this.onPanUpdate,
    required this.onPanEnd,
    required this.onDelete,
    required this.onSplit,
    required this.onRotateTap,
    required this.onRotatePanStart,
    required this.onRotatePanUpdate,
    required this.onRotatePanEnd,
    required this.onResizeTap,
    required this.onResizePanStart,
    required this.onResizePanUpdate,
    required this.onResizePanEnd,
  });

  @override
  Widget build(BuildContext context) {
    
    final bool canInteract = !isLocked && isEditingMode && isSelected;

    return Positioned(
      left: position.dx,
      top: position.dy,
      child: GestureDetector(
        
        onTap: !isLocked ? () => onTap(id) : null,
        onPanStart: canInteract ? (details) => onPanStart(id, details) : null,
        onPanUpdate: canInteract ? (details) => onPanUpdate(id, details.delta) : null,
        onPanEnd: canInteract ? (details) => onPanEnd(id) : null,
        child: Container(
          decoration: isSelected && isEditingMode
              ? BoxDecoration(
            border: Border.all(
                color: isLocked ? Colors.red.shade300 : Colors.black38,
                width: 3),
            borderRadius: BorderRadius.circular(6),
          )
              : null,
          padding: const EdgeInsets.all(2),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Transform.rotate(
                angle: rotation * pi / 180,
                child: Container(
                  padding: const EdgeInsets.all(12), 
                  child: child,
                ),
              ),

              
              if (canInteract) ...[
                Positioned(
                  top: -15,
                  left: -15,
                  child: CornerActionIcon(
                    icon: Icons.close,
                    onTap: () => onDelete(id),
                  ),
                ),
                Positioned(
                  top: -15,
                  right: -15,
                  child: CornerActionIcon(
                    icon: Icons.call_split,
                    onTap: () => onSplit(id),
                  ),
                ),
                Positioned(
                  bottom: -15,
                  left: -15,
                  child: CornerActionIcon(
                    icon: Icons.rotate_right,
                    onTap: () => onRotateTap(id),
                    onPanStart: (details) => onRotatePanStart(id, details),
                    onPanUpdate: (details) => onRotatePanUpdate(id, details),
                    onPanEnd: (details) => onRotatePanEnd(id),
                  ),
                ),
                Positioned(
                  bottom: -15,
                  right: -15,
                  child: CornerActionIcon(
                    icon: Icons.open_in_full,
                    onTap: () => onResizeTap(id),
                    onPanStart: (details) => onResizePanStart(id, details),
                    onPanUpdate: (details) => onResizePanUpdate(id, details),
                    onPanEnd: (details) => onResizePanEnd(id),
                  ),
                ),
              ],

              
              if (isLocked)
                Positioned.fill(
                  child: Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Icon(Icons.lock,
                        color: Colors.white,
                        size: 32,
                        shadows: [
                          Shadow(color: Colors.black, blurRadius: 4)
                        ]),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}