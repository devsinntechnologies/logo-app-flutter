import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_svg/svg.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class DownloadLogo extends StatefulWidget {
  final String svgLogo;
  final String companyName;
  final String sloganName;

  const DownloadLogo({
    super.key,
    required this.svgLogo,
    required this.companyName,
    required this.sloganName,
  });

  @override
  State<DownloadLogo> createState() => _DownloadLogoState();
}

class _DownloadLogoState extends State<DownloadLogo> {
  late Offset logoPosition;
  late Offset companyNamePosition;
  late Offset sloganPosition;

  // GlobalKey for capturing the widget as image
  final GlobalKey _canvasKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    logoPosition = const Offset(150, 100);
    companyNamePosition = const Offset(160, 200);
    sloganPosition = const Offset(150, 240);
  }

  bool isEditing = false;
  int? selectedElement;
  int selectedIndex = 0;

  double logoSize = 100;
  double companyNameSize = 20;
  double sloganSize = 18;

  double logoRotation = 0;
  double companyNameRotation = 0;
  double sloganRotation = 0;

  final double dragLimit = 300;

  Offset _limitOffset(Offset original, Offset delta) {
    final newOffset = original + delta;
    if (newOffset.dy > dragLimit) {
      return Offset(newOffset.dx, dragLimit);
    }
    return newOffset;
  }

  void _deleteElement() {
    setState(() {
      selectedElement = null;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Element deleted!')));
    });
  }

  void _splitElement() {
    setState(() {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Element split!')));
    });
  }

  void _rotateElement() {
    setState(() {
      if (selectedElement == 0) {
        logoRotation += 45;
        if (logoRotation >= 360) logoRotation = 0;
      } else if (selectedElement == 1) {
        companyNameRotation += 45;
        if (companyNameRotation >= 360) companyNameRotation = 0;
      } else if (selectedElement == 2) {
        sloganRotation += 45;
        if (sloganRotation >= 360) sloganRotation = 0;
      }
    });
  }

  void _resizeElement() {
    setState(() {
      if (selectedElement == 0) {
        logoSize = logoSize == 100 ? 150 : 100;
      } else if (selectedElement == 1) {
        companyNameSize = companyNameSize == 20 ? 30 : 20;
      } else if (selectedElement == 2) {
        sloganSize = sloganSize == 18 ? 26 : 18;
      }
    });
  }

  // Request storage permission
  Future<bool> _requestPermission() async {
    var status = await Permission.storage.status;
    if (!status.isGranted) {
      status = await Permission.storage.request();
    }
    return status.isGranted;
  }

  void _showSaveOptions() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Save Logo'),
          content: const Text('Choose format to save:'),
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _saveAsSVG();
                  },
                  child: const Text('Save as SVG'),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _saveAsPNG();
                  },
                  child: const Text('Save as PNG'),
                ),
              ],
            ),
            Center(
              child: TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text(
                  'Cancel',
                  style: TextStyle(color: Colors.redAccent),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // Generate SVG content
  String _generateSVGContent() {
    return '''
<svg width="400" height="350" xmlns="http://www.w3.org/2000/svg">
  <rect width="100%" height="100%" fill="white"/>
  
  <!-- Logo SVG -->
  <g transform="translate(${logoPosition.dx}, ${logoPosition.dy}) rotate($logoRotation, ${logoSize/2}, ${logoSize/2})">
    ${widget.svgLogo.replaceAll(RegExp(r'<\?xml[^>]*>'), '').replaceAll(RegExp(r'<svg[^>]*>'), '').replaceAll('</svg>', '')}
  </g>
  
  <!-- Company Name -->
  <text x="${companyNamePosition.dx}" y="${companyNamePosition.dy + companyNameSize}" 
        font-family="Arial, sans-serif" 
        font-size="$companyNameSize" 
        font-weight="bold" 
        fill="black"
        transform="rotate($companyNameRotation, ${companyNamePosition.dx}, ${companyNamePosition.dy + companyNameSize})">
    ${widget.companyName}
  </text>
  
  <!-- Slogan -->
  <text x="${sloganPosition.dx}" y="${sloganPosition.dy + sloganSize}" 
        font-family="Arial, sans-serif" 
        font-size="$sloganSize" 
        font-style="italic" 
        fill="black"
        transform="rotate($sloganRotation, ${sloganPosition.dx}, ${sloganPosition.dy + sloganSize})">
    ${widget.sloganName}
  </text>
</svg>
    ''';
  }

  // Save as SVG
  Future<void> _saveAsSVG() async {
    try {
      final hasPermission = await _requestPermission();
      if (!hasPermission) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Storage permission denied')),
        );
        return;
      }

      final directory = await getExternalStorageDirectory();
      final downloadsDirectory = Directory('${directory!.path}/Download');
      
      if (!await downloadsDirectory.exists()) {
        await downloadsDirectory.create(recursive: true);
      }

      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final file = File('${downloadsDirectory.path}/logo_$timestamp.svg');
      
      final svgContent = _generateSVGContent();
      await file.writeAsString(svgContent);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Logo saved as SVG: ${file.path}')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving SVG: $e')),
      );
    }
  }

  // Save as PNG
  Future<void> _saveAsPNG() async {
    try {
      final hasPermission = await _requestPermission();
      if (!hasPermission) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Storage permission denied')),
        );
        return;
      }

      // Capture the widget as image
      RenderRepaintBoundary boundary = _canvasKey.currentContext!
          .findRenderObject() as RenderRepaintBoundary;
      
      ui.Image image = await boundary.toImage(pixelRatio: 3.0);
      ByteData? byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      Uint8List pngBytes = byteData!.buffer.asUint8List();

      final directory = await getExternalStorageDirectory();
      final downloadsDirectory = Directory('${directory!.path}/Download');
      
      if (!await downloadsDirectory.exists()) {
        await downloadsDirectory.create(recursive: true);
      }

      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final file = File('${downloadsDirectory.path}/logo_$timestamp.png');
      
      await file.writeAsBytes(pngBytes);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Logo saved as PNG: ${file.path}')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving PNG: $e')),
      );
    }
  }

  Widget _buildCornerIcon({
    required IconData icon,
    required VoidCallback onTap,
    required Alignment alignment,
  }) {
    return Align(
      alignment: alignment,
      child: Transform.translate(
        offset: Offset(alignment.x * 15, alignment.y * 15),
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.black, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Icon(icon, size: 20, color: Colors.black),
          ),
        ),
      ),
    );
  }

  // scaffold
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey.shade200,
        title: Text(
          'Logo Maker',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.save, size: 40),
            onPressed: _showSaveOptions,
          ),
          IconButton(
            icon: const Icon(Icons.edit, size: 40),
            onPressed: () {
              setState(() {
                isEditing = !isEditing;
              });
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    isEditing
                        ? 'Editing mode enabled'
                        : 'Editing mode disabled',
                  ),
                ),
              );
            },
          ),
        ],
      ),

      // Main content
      body: Stack(
        children: [
          Container(height: 500, width: double.infinity, color: Colors.white),
          Column(
            children: [
              Expanded(
                child: RepaintBoundary(
                  key: _canvasKey,
                  child: Container(
                    color: Colors.white,
                    child: Stack(
                      children: [
                        // Company Name
                        Positioned(
                          left: companyNamePosition.dx,
                          top: companyNamePosition.dy,
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                selectedElement = 1;
                              });
                            },
                            onPanUpdate:
                                isEditing && selectedElement == 1
                                    ? (details) {
                                      setState(() {
                                        companyNamePosition = _limitOffset(
                                          companyNamePosition,
                                          details.delta,
                                        );
                                      });
                                    }
                                    : null,
                            child: Container(
                              decoration:
                                  selectedElement == 1
                                      ? BoxDecoration(
                                        border: Border.all(
                                          color: Colors.black38,
                                          width: 3,
                                        ),
                                        borderRadius: BorderRadius.circular(6),
                                      )
                                      : null,
                              padding: const EdgeInsets.all(2),
                              child: Stack(
                                clipBehavior: Clip.none,
                                children: [
                                  Transform.rotate(
                                    angle: companyNameRotation * 3.14159 / 180,
                                    child: Text(
                                      widget.companyName,
                                      style: TextStyle(
                                        fontSize: companyNameSize,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  if (selectedElement == 1 && isEditing) ...[
                                    Positioned(
                                      bottom: 0,
                                      right: 0,
                                      top: 0,
                                      left: 0,
                                      child: _buildCornerIcon(
                                        icon: Icons.close,
                                        onTap: _deleteElement,
                                        alignment: Alignment.topLeft,
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 0,
                                      right: 0,
                                      top: 0,
                                      left: 0,
                                      child: _buildCornerIcon(
                                        icon: Icons.call_split,
                                        onTap: _splitElement,
                                        alignment: Alignment.topRight,
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 0,
                                      right: 0,
                                      top: 0,
                                      left: 0,
                                      child: _buildCornerIcon(
                                        icon: Icons.rotate_right,
                                        onTap: _rotateElement,
                                        alignment: Alignment.bottomLeft,
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 0,
                                      right: 0,
                                      top: 0,
                                      left: 0,
                                      child: _buildCornerIcon(
                                        icon: Icons.open_in_full,
                                        onTap: _resizeElement,
                                        alignment: Alignment.bottomRight,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        ),

                        // Slogan
                        Positioned(
                          left: sloganPosition.dx,
                          top: sloganPosition.dy,
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                selectedElement = 2;
                              });
                            },
                            onPanUpdate:
                                isEditing && selectedElement == 2
                                    ? (details) {
                                      setState(() {
                                        sloganPosition = _limitOffset(
                                          sloganPosition,
                                          details.delta,
                                        );
                                      });
                                    }
                                    : null,
                            child: Container(
                              decoration:
                                  selectedElement == 2
                                      ? BoxDecoration(
                                        border: Border.all(
                                          color: Colors.black38,
                                          width: 3,
                                        ),
                                        borderRadius: BorderRadius.circular(6),
                                      )
                                      : null,
                              padding: const EdgeInsets.all(2),
                              child: Stack(
                                clipBehavior: Clip.none,
                                children: [
                                  Transform.rotate(
                                    angle: sloganRotation * 3.14159 / 180,
                                    child: Text(
                                      widget.sloganName,
                                      style: TextStyle(
                                        fontSize: sloganSize,
                                        fontStyle: FontStyle.italic,
                                      ),
                                    ),
                                  ),
                                  if (selectedElement == 2 && isEditing) ...[
                                    Positioned(
                                      bottom: 0,
                                      right: 0,
                                      top: 0,
                                      left: 0,
                                      child: _buildCornerIcon(
                                        icon: Icons.close,
                                        onTap: _deleteElement,
                                        alignment: Alignment.topLeft,
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 0,
                                      right: 0,
                                      top: 0,
                                      left: 0,
                                      child: _buildCornerIcon(
                                        icon: Icons.call_split,
                                        onTap: _splitElement,
                                        alignment: Alignment.topRight,
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 0,
                                      right: 0,
                                      top: 0,
                                      left: 0,
                                      child: _buildCornerIcon(
                                        icon: Icons.rotate_right,
                                        onTap: _rotateElement,
                                        alignment: Alignment.bottomLeft,
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 0,
                                      right: 0,
                                      top: 0,
                                      left: 0,
                                      child: _buildCornerIcon(
                                        icon: Icons.open_in_full,
                                        onTap: _resizeElement,
                                        alignment: Alignment.bottomRight,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        ),

                        // Logo
                        Positioned(
                          left: logoPosition.dx,
                          top: logoPosition.dy,
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                selectedElement = 0;
                              });
                            },
                            onPanUpdate:
                                isEditing && selectedElement == 0
                                    ? (details) {
                                      setState(() {
                                        logoPosition = _limitOffset(
                                          logoPosition,
                                          details.delta,
                                        );
                                      });
                                    }
                                    : null,
                            child: Container(
                              decoration:
                                  selectedElement == 0
                                      ? BoxDecoration(
                                        border: Border.all(
                                          color: Colors.black38,
                                          width: 3,
                                        ),
                                        borderRadius: BorderRadius.circular(6),
                                      )
                                      : null,
                              padding: const EdgeInsets.all(2),
                              child: Stack(
                                clipBehavior: Clip.none,
                                children: [
                                  Transform.rotate(
                                    angle: logoRotation * 3.14159 / 180,
                                    child: SvgPicture.string(
                                      widget.svgLogo,
                                      height: logoSize,
                                      width: logoSize,
                                    ),
                                  ),
                                  if (selectedElement == 0 && isEditing) ...[
                                    Positioned(
                                      bottom: 0,
                                      right: 0,
                                      top: 0,
                                      left: 0,
                                      child: _buildCornerIcon(
                                        icon: Icons.close,
                                        onTap: _deleteElement,
                                        alignment: Alignment.topLeft,
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 0,
                                      right: 0,
                                      top: 0,
                                      left: 0,
                                      child: _buildCornerIcon(
                                        icon: Icons.call_split,
                                        onTap: _splitElement,
                                        alignment: Alignment.topRight,
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 0,
                                      right: 0,
                                      top: 0,
                                      left: 0,
                                      child: _buildCornerIcon(
                                        icon: Icons.rotate_right,
                                        onTap: _rotateElement,
                                        alignment: Alignment.bottomLeft,
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 0,
                                      right: 0,
                                      top: 0,
                                      left: 0,
                                      child: _buildCornerIcon(
                                        icon: Icons.open_in_full,
                                        onTap: _resizeElement,
                                        alignment: Alignment.bottomRight,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Column(
                children: [Container(height: 300, color: Colors.grey.shade200)],
              ),
            ],
          ),
        ],
      ),

      //bottom bar
      bottomNavigationBar: BottomAppBar(
        color: Colors.black,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(5, (index) {
            IconData iconData;
            String label;
            VoidCallback onTap;

            switch (index) {
              case 0:
                iconData = Icons.layers;
                label = 'Background';
                onTap = () {
                  setState(() {
                    isEditing = !isEditing;
                    selectedIndex = 0;
                  });
                };
                break;
              case 1:
                iconData = Icons.article_rounded;
                label = 'Art';
                onTap = () {
                  setState(() {
                    selectedIndex = 1;
                  });
                };
                break;
              case 2:
                iconData = Icons.text_fields_outlined;
                label = 'Text';
                onTap = () {
                  setState(() {
                    selectedIndex = 2;
                  });
                };
                break;
              case 3:
                iconData = Icons.edit;
                label = 'Effects';
                onTap = () {
                  setState(() {
                    selectedIndex = 3;
                  });
                };
                break;
              case 4:
              default:
                iconData = Icons.image;
                label = 'Images';
                onTap = () {   
                  setState(() {
                    selectedIndex = 4;
                  });
                };
                break;
            }

            final isSelected = selectedIndex == index;

            return GestureDetector(
              onTap: onTap,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: isSelected ? Colors.white : Colors.transparent,
                    ),
                    padding: const EdgeInsets.all(8),
                    child: Icon(
                      iconData,
                      color: isSelected ? Colors.black : Colors.white,
                      size: 20,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    label,
                    style: const TextStyle(color: Colors.white, fontSize: 10),
                  ),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}