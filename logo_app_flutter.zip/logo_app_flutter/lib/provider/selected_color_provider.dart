import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

class SelectedColorProvider extends ChangeNotifier {
  Color _selectedColor = Colors.white;
  Gradient? _selectedGradient;
  ui.Image? _backgroundImage; 
  File? _imageFile;           

  Color get selectedColor => _selectedColor;
  Gradient? get selectedGradient => _selectedGradient;
  ui.Image? get backgroundImage => _backgroundImage;
  File? get imageFile => _imageFile;

  void setColor(Color color) {
    _selectedColor = color;
    _selectedGradient = null;
    _backgroundImage = null;
    notifyListeners();
  }

  void setGradient(Gradient gradient) {
    _selectedGradient = gradient;
    _backgroundImage = null;
    notifyListeners();
  }

  void setBackgroundImage(ui.Image image, File? file) {
    _backgroundImage = image;
    _selectedGradient = null;
    _selectedColor = Colors.transparent;
    _imageFile = file;
    notifyListeners();
  }

  void clearAll() {
    _backgroundImage = null;
    _imageFile = null;
    _selectedGradient = null;
    _selectedColor = Colors.white;
    notifyListeners();
  }
}
